from rekurzija import print_string_recursive

string = input("Unesite string: ")
print("Ispis stringa: ")
print_string_recursive(string)